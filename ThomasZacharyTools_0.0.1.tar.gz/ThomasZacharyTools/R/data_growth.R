
           #' Example data from data
           #'
           #' @author Charlie Geyer \email{geyer@umn.edu}
           #' @references \url{http://www.stat.umn.edu/geyer/3701/data/growth.csv}
           "growth" 