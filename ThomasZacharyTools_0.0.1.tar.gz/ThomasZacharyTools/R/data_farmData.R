
           #' Example data from Lecture 7
           #'
           #' @author Zack Almquist \email{almquist@umn.edu}
           #' @references \url{http://users.stat.umn.edu/~almquist/3811_examples/data.csv}
           "farmData" 