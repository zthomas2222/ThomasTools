
           #' Example data from HW 1
           #'
           #' @author Charlie Geyer \email{geyer@umn.edu}
           #' @references \url{http://www.stat.umn.edu/geyer/3701/data/q1p4.txt}
           "d" 