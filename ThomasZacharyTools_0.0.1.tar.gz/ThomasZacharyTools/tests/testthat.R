library(testthat)
library(ThomasZacharyTools)

test_check("ThomasZacharyTools")
